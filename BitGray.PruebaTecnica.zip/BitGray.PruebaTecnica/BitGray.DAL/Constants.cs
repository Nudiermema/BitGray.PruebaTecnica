﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitGray.DAL
{
    class Constants
    {
        const string POST = "posts";
        const string COMMENTS = "comments";
        const string ALBUMS = "albums";
        const string PHOTOS = "photos";
        const string USERS = "users";
    }
}