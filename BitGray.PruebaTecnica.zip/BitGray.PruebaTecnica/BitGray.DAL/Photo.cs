﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitGray.DAL
{
    public class Photo
    {     
        public object GetAllPhotos()
        {
            const string Query = "photos";
            var Photos = Helper.CreateRequest(Query);
            return Photos;
        }      
    }
}