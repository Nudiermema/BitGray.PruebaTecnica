﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net;
using System.IO;
using System.Text;

namespace BitGray.DAL
{
    public class Helper
    {
        public static string CreateURI()
        {
            return ConfigurationManager.AppSettings["typicode"];
        }

        public static string CreateRequest(string jsonContent)
        {
            string content = CreateURI() + jsonContent;
            long length = 0;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(content);
            request.Method = "GET";
            request.ContentType = @"application/json";

            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        throw new Exception(String.Format("Server error (HTTP {0}: {1}).", response.StatusCode, response.StatusDescription));

                    using (Stream responseStream = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                        length = response.ContentLength;
                        if (length == 0)
                            throw new ApplicationException("El Consumo del web service " + CreateURI() + " no respodió nada");
                        return reader.ReadToEnd();
                    }
                }
            }
            catch (WebException ex)
            {
                WebResponse errorResponse = ex.Response;
                using (Stream responseStream = errorResponse.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.GetEncoding("utf-8"));
                    String errorText = reader.ReadToEnd();
                }
                throw;
            }
        }
    }
}