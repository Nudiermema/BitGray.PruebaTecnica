﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BitGray.DAL
{
    public class Album
    {
       
        public object GetAllAlbums()
        {
            const string query = "albums";
            var listaUsarios = Helper.CreateRequest(query);
            return listaUsarios;
        }
    }
}