﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BitGray.DAL
{
    public class Post
    {
      
        public object GetAllPost()
        {
            const string query = "posts";
            var listaPost = Helper.CreateRequest(query);
            return listaPost;
        }

    }
}