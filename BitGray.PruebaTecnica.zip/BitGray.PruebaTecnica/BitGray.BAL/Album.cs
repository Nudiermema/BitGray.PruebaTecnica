﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace BitGray.BAL
{
    public class Album
    {
        [DataMember(Name = "userId")]
        public int UserID { get; set; }
        [DataMember(Name = "id")]
        public int ID { get; set; }
        [DataMember(Name = "title")]
        public string Title { get; set; }
        DAL.Album album;

        /// <summary>
        /// Get all Album from the Web Api
        /// </summary>
        /// <returns></returns>
        public List<Album> GetAllAlbums()
        {
            album = new DAL.Album();            
            return JsonConvert.DeserializeObject<List<Album>>(album.GetAllAlbums().ToString());
        }

        /// <summary>
        /// Get all Album that belongs to an specific User
        /// </summary>
        /// <returns></returns>
        public List<Album> GetAlbumForUSer(int UserID)
        {
            var albums = GetAllAlbums().AsQueryable();
            return albums.Where(x => x.UserID == UserID).ToList();
        }

    }
}