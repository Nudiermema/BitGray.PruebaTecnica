﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace BitGray.BAL
{
    public class Post
    {
        [DataMember(Name = "userId")]
        public int UserID { get; set; }
        [DataMember(Name = "title")]
        public int ID { get; set; }
        public string Title { get; set; }
        [DataMember(Name = "body")]
        public string Body { get; set; }
        DAL.Post dalPost = null;

        /// <summary>
        /// Get all created posts
        /// </summary>
        /// <returns>List with the posts</returns>
        public List<Post> GetAllPost()
        {
            dalPost = new DAL.Post();
            return JsonConvert.DeserializeObject<List<Post>>(dalPost.GetAllPost().ToString());
        }
    }
}