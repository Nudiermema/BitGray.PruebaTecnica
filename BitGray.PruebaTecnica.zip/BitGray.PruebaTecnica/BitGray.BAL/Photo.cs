﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace BitGray.BAL
{
    public class Photo
    {
        [DataMember(Name = "albumId")]
        public int AlbumID { get; set; }
        [DataMember(Name = "id")]
        public int ID { get; set; }
        [DataMember(Name = "title")]
        public string Title { get; set; }
        [DataMember(Name = "url")]
        public string Url { get; set; }
        [DataMember(Name = "thumbNailUrl")]
        public string ThumbNailUrl { get; set; }
        DAL.Photo photo;

        /// <summary>
        /// Get all Photos from the Web Api
        /// </summary>
        /// <returns></returns>
        public List<Photo> GetAllPhotos()
        {
            photo = new DAL.Photo();
            return JsonConvert.DeserializeObject<List<Photo>>(photo.GetAllPhotos().ToString());
        }

        /// <summary>
        /// Get all Photos that belongs to specific Album
        /// </summary>
        /// <returns></returns>
        public List<Photo> GetPhotosForAlbum(int albumId)
        {
            var photos = GetAllPhotos().AsQueryable();
            return photos.Where(x => x.AlbumID == albumId).ToList();
        }
    }
}