﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Web.Script.Serialization;
using Newtonsoft.Json;

namespace BitGray.BAL
{
    public class User
    {
        [DataMember(Name = "id")]
        public int ID { get; set; }
        [DataMember(Name = "name")]
        public string Name { get; set; }
        [DataMember(Name = "username")]
        public string UserName { get; set; }
        [DataMember(Name = "email")]
        public string Email { get; set; }
        [DataMember(Name = "address")]
        internal Address Address { get; set; }
        [DataMember(Name = "geo")]
        internal Geo Geo { get; set; }
        [DataMember(Name = "phone")]
        public string Phone { get; set; }
        [DataMember(Name = "website")]
        public string WebSite { get; set; }
        [DataMember(Name = "company")]
        public Company Company { get; set; }
        DAL.User dalUser;

        /// <summary>m
        /// Get a ramdomized user
        /// </summary>
        /// <returns></returns>
        public User GetRandomUser()
        {
            int cont = 0;
            var usuarios = GetAllUsers();
            cont = usuarios.Count;
            Random r = new Random();
            int generatedNumber = r.Next(cont);
            return usuarios[generatedNumber];
        }

        /// <summary>
        /// Get all users from the Web Api
        /// </summary>
        /// <returns></returns>
        public List<User> GetAllUsers()
        {
            List<User> ListaUsers = new List<User>();
            dalUser = new DAL.User();
            var UserData = JsonConvert.DeserializeObject<List<User>>(dalUser.GetAllUsers().ToString());
            foreach (var item in UserData)
            {
                ListaUsers.Add(new User() { ID = item.ID, Name = item.Name, UserName = item.UserName, Email = item.Email, Phone = item.Phone, Company = item.Company });
            }
            return ListaUsers;
        }
    }
}
