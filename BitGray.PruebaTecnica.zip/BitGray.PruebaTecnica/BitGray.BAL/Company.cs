﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BitGray.BAL
{
   public class Company
    {
       [DataMember(Name = "name")]
        public string Name { get; set; }
       [DataMember(Name = "catchPhrase")]
        public string catchPhrase { get; set; }
       [DataMember(Name = "bs")]
        public string BS { get; set; }
    }
}
