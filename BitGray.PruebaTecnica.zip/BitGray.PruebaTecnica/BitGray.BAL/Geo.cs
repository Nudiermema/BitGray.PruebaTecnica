﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BitGray.BAL
{
    internal class Geo
    {
        [DataMember(Name = "lag")]
        public float Phone { get; set; }
        [DataMember(Name = "lang")]
        public float company { get; set; }

    }
}
