﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BitGray.BAL
{
    internal class Address
    {
        [DataMember(Name = "street")]
        public string Street { get; set; }
        [DataMember(Name = "suite")]
        public string Suite { get; set; }
        [DataMember(Name = "city")]
        public string City { get; set; }
        [DataMember(Name = "zipcode")]
        public string ZipCode { get; set; }
    }
}
