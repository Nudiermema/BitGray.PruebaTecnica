﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BitGray.BAL;


namespace BitGray.View
{
    public partial class Posts : Form
    {
        Post post;
        log4net.ILog logger = log4net.LogManager.GetLogger(typeof(Posts)); 
        public Posts()
        {
            InitializeComponent();
        }

        private void Post_Load(object sender, EventArgs e)
        {
            BindPostDataGrid();
        }

        private void BindPostDataGrid()
        {
            try
            {
                post = new Post();
                dgrPost.DataSource = post.GetAllPost();
            }
            catch (Exception ex)
            {
                logger.Debug(ex.ToString());
                MessageBox.Show(" The operation cannot be performed, an error has occurred");
            }
        }
    }
}
