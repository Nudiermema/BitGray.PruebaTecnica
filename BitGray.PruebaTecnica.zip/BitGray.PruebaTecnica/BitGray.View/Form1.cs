﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BitGray.BAL;


namespace BitGray.View
{
    public partial class Form1 : Form
    {
        log4net.ILog logger = log4net.LogManager.GetLogger(typeof(Form1)); 
        User user;
        public static int UserId { get; set; }
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            BindRandomUser();
        }

        /// <summary>
        /// Bind the generated user to the form
        /// </summary>
        private void BindRandomUser()
        {
            try
            {
                user = new User();
                var getUser = user.GetRandomUser();
                UserId = getUser.ID;
                this.lblNombre.Text = getUser.Name;
                this.lblUsuario.Text = getUser.UserName;
                this.lblCorreo.Text = getUser.Email;
                this.lblTelefono.Text = getUser.Phone;
                this.lblCompania.Text = getUser.Company.Name;
            }
            catch (Exception ex)
            {
                logger.Debug(ex.ToString());
                MessageBox.Show(" The operation cannot be performed, an error has occurred");
            }
        }

        private void usuariosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new Usuario().Show();

            //Usuario usuario = new Usuario();
            //usuario.Show();
        }

        private void postToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new Posts().Show();

            //Posts postForm = new Posts();
            //postForm.Show();
        }

        private void fotosAlbumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Fotos_Album().Show();

            //Fotos_Album fotos = new Fotos_Album();
            //fotos.Show();

        }

        private void cerrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
