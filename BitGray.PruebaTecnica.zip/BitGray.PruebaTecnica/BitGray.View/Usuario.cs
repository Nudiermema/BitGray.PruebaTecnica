﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BitGray.BAL;
using log4net;

namespace BitGray.View
{
    public partial class Usuario : Form
    {
        User user;
        ILog logger = log4net.LogManager.GetLogger(typeof(Usuario));

        public Usuario()
        {
            InitializeComponent();
        }

        private void Usuario_Load(object sender, EventArgs e)
        {
            BindDataGridUsers();

        }

        /// <summary>
        /// Bind the List of users to the DataGridView
        /// </summary>
        private void BindDataGridUsers()
        {
            user = new User();
            this.drgUsers.AutoGenerateColumns = false;
            this.drgUsers.Columns[4].DataPropertyName = "Company.Name";
            try
            {
                this.drgUsers.DataSource = user.GetAllUsers();
            }
            catch (Exception ex)
            {
                logger.Debug(ex.ToString());
                MessageBox.Show(" The operation cannot be performed, an error has occurred");
            }
        }
    }
}
