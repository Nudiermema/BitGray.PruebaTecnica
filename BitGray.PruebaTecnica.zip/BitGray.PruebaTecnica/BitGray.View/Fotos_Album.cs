﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BitGray.BAL;
using System.Net;

namespace BitGray.View
{
    public partial class Fotos_Album : Form
    {
        Album album;
        Photo photo;
        log4net.ILog logger = log4net.LogManager.GetLogger(typeof(Fotos_Album));      
        public Fotos_Album()
        {
            InitializeComponent();
        }

        private void Fotos_Album_Load(object sender, EventArgs e)
        {            
            GetAlbumForUser(Form1.UserId);
        }


        private void GetAlbumForUser(int userID)
        {
            album = new Album();            
            try
            {
                this.dgrAlbum.DataSource = album.GetAlbumForUSer(userID);
            }
            catch (Exception ex)
            {
                logger.Debug(ex.ToString());
                MessageBox.Show(" The operation cannot be performed, an error has occurred");
            }
        }

        private void GetPhotosForAlbum(int albumID)
        {
            photo = new Photo();
            try
            {
                this.dgrPhotos.DataSource = photo.GetPhotosForAlbum(albumID);
            }
            catch (Exception ex)
            {
                logger.Debug(ex.ToString());
                MessageBox.Show(" The operation cannot be performed, an error has occurred");
            }
        }     

        private void dgrAlbum_CurrentCellChanged(object sender, EventArgs e)
        {
            int seleccion = 0;
            foreach (DataGridViewCell item in this.dgrAlbum.SelectedCells)
            {                
                if (!item.Selected)
                {
                    continue;
                }
                else
                {
                    seleccion = int.Parse(item.Value.ToString());
                    GetPhotosForAlbum(seleccion);
                    this.dgrPhotos.Visible = true;
                    break;
                }
            }
        }        
    }
}
