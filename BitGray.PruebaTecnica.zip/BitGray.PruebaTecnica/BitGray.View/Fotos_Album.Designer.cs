﻿namespace BitGray.View
{
    partial class Fotos_Album
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgrAlbum = new System.Windows.Forms.DataGridView();
            this.UserID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewLinkColumn();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgrPhotos = new System.Windows.Forms.DataGridView();
            this.AlbumID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Codigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Titulo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Url = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Imagen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgrAlbum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgrPhotos)).BeginInit();
            this.SuspendLayout();
            // 
            // dgrAlbum
            // 
            this.dgrAlbum.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrAlbum.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UserID,
            this.ID,
            this.Title});
            this.dgrAlbum.Location = new System.Drawing.Point(92, 59);
            this.dgrAlbum.Name = "dgrAlbum";
            this.dgrAlbum.Size = new System.Drawing.Size(670, 249);
            this.dgrAlbum.TabIndex = 0;
            this.dgrAlbum.CurrentCellChanged += new System.EventHandler(this.dgrAlbum_CurrentCellChanged);
            // 
            // UserID
            // 
            this.UserID.DataPropertyName = "UserID";
            this.UserID.HeaderText = "UserID";
            this.UserID.Name = "UserID";
            this.UserID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Title
            // 
            this.Title.DataPropertyName = "Title";
            this.Title.HeaderText = "Title";
            this.Title.Name = "Title";
            // 
            // dgrPhotos
            // 
            this.dgrPhotos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrPhotos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AlbumID,
            this.Codigo,
            this.Titulo,
            this.Url,
            this.Imagen});
            this.dgrPhotos.Location = new System.Drawing.Point(92, 327);
            this.dgrPhotos.Name = "dgrPhotos";
            this.dgrPhotos.Size = new System.Drawing.Size(670, 274);
            this.dgrPhotos.TabIndex = 1;
            this.dgrPhotos.Visible = false;
            // 
            // AlbumID
            // 
            this.AlbumID.DataPropertyName = "AlbumID";
            this.AlbumID.HeaderText = "Album ID";
            this.AlbumID.Name = "AlbumID";
            // 
            // Codigo
            // 
            this.Codigo.DataPropertyName = "ID";
            this.Codigo.HeaderText = "Codigo";
            this.Codigo.Name = "Codigo";
            // 
            // Titulo
            // 
            this.Titulo.DataPropertyName = "Title";
            this.Titulo.HeaderText = "Titulo";
            this.Titulo.Name = "Titulo";
            // 
            // Url
            // 
            this.Url.DataPropertyName = "Url";
            this.Url.HeaderText = "Url";
            this.Url.Name = "Url";
            // 
            // Imagen
            // 
            this.Imagen.DataPropertyName = "ThumbnailUrl";
            this.Imagen.HeaderText = "Imagen";
            this.Imagen.Name = "Imagen";
            this.Imagen.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(282, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(352, 39);
            this.label1.TabIndex = 2;
            this.label1.Text = "Listado Album / Fotos";
            // 
            // Fotos_Album
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 613);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgrPhotos);
            this.Controls.Add(this.dgrAlbum);
            this.MaximizeBox = false;
            this.Name = "Fotos_Album";
            this.Text = "Formulario Fotos / Album";
            this.Load += new System.EventHandler(this.Fotos_Album_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgrAlbum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgrPhotos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgrAlbum;
        private System.Windows.Forms.DataGridView dgrPhotos;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserID;
        private System.Windows.Forms.DataGridViewLinkColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn AlbumID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Codigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Titulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Url;
        private System.Windows.Forms.DataGridViewTextBoxColumn Imagen;
        private System.Windows.Forms.Label label1;
    }
}